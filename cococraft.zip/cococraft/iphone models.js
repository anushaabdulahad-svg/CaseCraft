function openModal() {
  document.getElementById("modelModal").style.display = "block";
}

function closeModal() {
  document.getElementById("modelModal").style.display = "none";
}
