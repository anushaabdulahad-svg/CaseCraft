import glob
import re

files = glob.glob(r"c:/Users/Hamza-PC/Anusha Abdul Ahad_canva lab task/Desktop/ihatemylife/cococraft/iphone*.html")

LOGIN_BLOCK = """
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true";
    if (!isLoggedIn) {
        alert("Please login to proceed.");
        window.location.href = "login.html";
        return;
    }
"""

for file_path in files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Regex to find the start of addToCart function
    # It usually starts with: function addToCart() {
    # We want to insert the LOGIN_BLOCK right after the opening brace.
    
    pattern = r'(function\s+addToCart\s*\(\s*\)\s*\{)'
    
    # Check if we already have the login check to avoid double insertion
    if 'alert("Please login to proceed.");' in content:
        print(f"Skipping {file_path} - already has login check.")
        continue

    # Perform replacement
    # re.sub(pattern, r'\1' + LOGIN_BLOCK, content, count=1)
    
    new_content = re.sub(pattern, lambda m: m.group(1) + LOGIN_BLOCK, content, count=1)
    
    if new_content != content:
        print(f"Updating login check in {file_path}")
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)

print("All files updated.")
