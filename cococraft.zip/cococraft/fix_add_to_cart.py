import glob
import re
import os

files = glob.glob(r"c:/Users/Hamza-PC/Anusha Abdul Ahad_canva lab task/Desktop/ihatemylife/cococraft/iphone*.html")

# The block we want to remove/replace
# It looks usually like:
#     const isLoggedIn = localStorage.getItem("userLoggedIn") === "true";
#     if (!isLoggedIn) {
#         alert("Please login to proceed to checkout.");
#         window.location.href = "login.html?redirect=checkout.html";
#     } else {
#         window.location.href = "checkout.html";
#     }

redirect_pattern = re.compile(
    r'const\s+isLoggedIn\s*=\s*localStorage\.getItem\("userLoggedIn"\)\s*===\s*"true";\s*'
    r'if\s*\(!isLoggedIn\)\s*\{\s*'
    r'alert\("Please login to proceed to checkout\."\);\s*'
    r'window\.location\.href\s*=\s*"login\.html\?redirect=checkout\.html";\s*'
    r'\}\s*else\s*\{\s*'
    r'window\.location\.href\s*=\s*"checkout\.html";\s*'
    r'\}',
    re.DOTALL
)

for file_path in files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    new_content = redirect_pattern.sub('alert("Item added to cart successfully!");', content)
    
    # Also catch simple window.location.href = "checkout.html"; if not inside the block above (fallback)
    # But only if it's inside addToCart function? 
    # Actually, if I just replaced the big block, that covers the common case.
    # If the file hasn't been touched, we write it.
    
    if new_content != content:
        print(f"Fixed logic in {file_path}")
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
