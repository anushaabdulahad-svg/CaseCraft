
import os
import glob
import re

def fix_color_save(directory):
    files = glob.glob(os.path.join(directory, "iphone*.html"))
    count = 0
    
    for filepath in files:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        modified = False
        
        # Repair saveProgress
        # Look for: bg: document.getElementById('design').style.background
        # Replace: bg: document.getElementById('design').style.backgroundColor
        if "bg: document.getElementById('design').style.background," in content:
            content = content.replace(
                "bg: document.getElementById('design').style.background,",
                "bg: document.getElementById('design').style.backgroundColor,"
            )
            modified = True
        
        # Repair loadProgress
        # Look for: if (data.bg) design.style.background = data.bg;
        # Replace: if (data.bg) design.style.backgroundColor = data.bg;
        if "if (data.bg) design.style.background = data.bg;" in content:
            content = content.replace(
                "if (data.bg) design.style.background = data.bg;",
                "if (data.bg) design.style.backgroundColor = data.bg;"
            )
            modified = True
            
        if modified:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Fixed {os.path.basename(filepath)}")
            count += 1
            
    print(f"Total files fixed: {count}")

if __name__ == "__main__":
    target_dir = r"c:/Users/Hamza-PC/Anusha Abdul Ahad_canva lab task/Desktop/COCOcraft(S.E) - Copy - Copy/cococraft"
    fix_color_save(target_dir)
