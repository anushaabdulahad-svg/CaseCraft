function changeImage(thumbnail) {
  const mainImage = document.getElementById("productImage");

  // smooth fade effect
  mainImage.style.opacity = "0";

  setTimeout(() => {
    mainImage.src = thumbnail.src;
    mainImage.style.opacity = "1";
  }, 200);

  // auto scroll to image (smooth)
  mainImage.scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
}
