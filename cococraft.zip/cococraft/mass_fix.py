import glob
import re
import os

files = glob.glob(r"c:/Users/Hamza-PC/Anusha Abdul Ahad_canva lab task/Desktop/ihatemylife/cococraft/iphone*.html")

checkout_logic = """
function goToCheckout() {
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true";
    if (!isLoggedIn) {
        alert("Please login to proceed to checkout.");
        window.location.href = "login.html?redirect=checkout.html";
    } else {
        window.location.href = "checkout.html";
    }
}
"""

controls_css_fix = """
    .container {
      display: flex;
      gap: 30px;
      align-items: flex-start;
    }
    .controls {
      display: flex;
      flex-direction: row;
      gap: 30px;
      align-items: flex-start;
      width: auto !important;
    }
    .color-section {
      width: 150px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .sticker-section {
      width: 150px;
    }
"""

for file_path in files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    original_content = content
    modified = False
    
    # 1. Update Checkout Button
    # Look for button named Checkout
    # Regex: <button class="action-btn" onclick="[^"]*">Checkout</button>
    # Note: onclick might be different or attributes order differs.
    # Try generic: <button[^>]*>Checkout</button>
    
    def repl_checkout_btn(match):
        btn_tag = match.group(0)
        if 'goToCheckout()' in btn_tag:
            return btn_tag
        # Replace onclick content
        if 'onclick="' in btn_tag:
             return re.sub(r'onclick="[^"]*"', 'onclick="goToCheckout()"', btn_tag)
        else:
             # insert onclick
             return btn_tag.replace('<button', '<button onclick="goToCheckout()"')

    new_content = re.sub(r'<button[^>]*>\s*Checkout\s*</button>', repl_checkout_btn, content, flags=re.IGNORECASE)
    if new_content != content:
        content = new_content
        modified = True

    # 2. Inject goToCheckout and fix addToCart
    if 'function goToCheckout' not in content:
        # Append before last </script>
        last_script_end = content.rfind('</script>')
        if last_script_end != -1:
            content = content[:last_script_end] + checkout_logic + content[last_script_end:]
            modified = True

    # Fix addToCart redirect
    # Find addToCart logic and replace redirection
    # We look for window.location.href = ... inside addToCart
    # This is tricky with simple regex, but let's try to target the specific redirection line commonly used
    
    # Common pattern: window.location.href = "checkout.html"; inside addToCart
    # We want to replace it with alert...
    
    # However, we must ensure it's inside addToCart.
    # Let's assume occurrences of redirection to checkout.html typically happen in addToCart or buyNow.
    # But wait, if I previously added goToCheckout logic to buttons, old inline redirects might not be clicked.
    # BUT addToCart function might still redirect automatically? User said "when user clicks add to cart it adds ... make it so it adds ... ".
    # In many files, addToCart likely redirects to checkout immediately.
    
    # Let's replace 'window.location.href = "checkout.html";' with 'alert("Item added to cart successfully!");'
    # BUT ONLY if it's not inside goToCheckout (which we just added/checked).
    # Since goToCheckout HAS 'window.location.href = "checkout.html"', we must be careful.
    
    # My injected goToCheckout has: window.location.href = "checkout.html";
    # The existing bad code likely has: window.location.href = 'checkout.html' or similar.
    
    # Re-reading iphone11.html logic:
    # It has: window.location.href = "checkout.html"; inside addToCart logic (isLoggedIn check).
    # Wait, iphone11.html ALREADY has logic to check login and redirect.
    # User wants "Add to cart" to just ADD (and alert), NOT redirect to checkout.
    # So in `addToCart`, I should REMOVE the redirection/navigation.
    
    # Strategy: Find `function addToCart` block.
    # Inside it, find `window.location.href = ...checkout...`
    # Replace with alert.
    
    cart_match = re.search(r'function addToCart\(\s*\)\s*\{([\s\S]*?)\}', content)
    if cart_match:
        cart_body = cart_match.group(1)
        # Check if it redirects
        if 'window.location.href' in cart_body and ('checkout.html' in cart_body or 'login.html' in cart_body):
             # Replace the redirection logic block with alert
             # We might cut out the whole if/else check for login if it exists solely for redirecting to checkout immediatey
             # But maybe we just want to replace the `window.location.href = ...` with alert?
             # Actually, if we just want to add to cart, we don't need login check (usually). Login check is for checkout.
             # So we can remove the login check from addToCart entirely?
             # Yes, "add to cart" usually doesn't require login until checkout.
             
             # Re-construct addToCart body: replace lines involving window.location with alert.
             
             new_cart_body = re.sub(r'window\.location\.href\s*=\s*["\'].*?checkout\.html["\'];', 'alert("Item added to cart successfully!");', cart_body)
             new_cart_body = re.sub(r'window\.location\.href\s*=\s*["\'].*?login\.html.*?["\'];', 'alert("Item added to cart successfully!");', new_cart_body)
             
             # Also remove the if(isLoggedIn) block if it wraps the redirect?
             # This is hard to robustly parse with regex.
             # Alternative: Explicitly replace the common block I see in iphone11.html
             
             common_redirect_block = r"""const isLoggedIn = localStorage.getItem\("userLoggedIn"\) === "true";\s*if \(!isLoggedIn\) \{\s*alert\("Please login to proceed to checkout."\);\s*window.location.href = "login.html\?redirect=checkout.html";\s*\} else \{\s*window.location.href = "checkout.html";\s*\}"""
             
             if re.search(common_redirect_block, cart_body):
                  new_cart_body = re.sub(common_redirect_block, 'alert("Item added to cart successfully!");', cart_body)
             
             if new_cart_body != cart_body:
                 content = content.replace(cart_body, new_cart_body)
                 modified = True

    # 3. Specific 4S Fixes
    if 'iphone4S.html' in file_path:
        # Fix Structure
        # 1. Add class="sticker-section" to the div containing <h4>Stickers</h4>
        # Regex: <div>\s*<h4>Stickers</h4> (ensure no attributes)
        if re.search(r'<div>\s*<h4>Stickers</h4>', content):
            content = re.sub(r'<div>\s*<h4>Stickers</h4>', r'<div class="sticker-section">\n        <h4>Stickers</h4>', content)
            modified = True
            
        # 2. Fix CSS of .controls
        # Find the .controls css block
        # .controls {\s*display: flex;\s*gap: 25px;\s*width: 300px;\s*.*?\}
        # This is surprisingly hard to match reliably if formatting varies.
        # But I saw it earlier.
        # Let's simple search and replace text if it matches close enough.
        
        bad_controls_css = """
    .controls {
      display: flex;
      gap: 25px;
      width: 300px;
      /* ?? IMPORTANT */
    }
"""
        # approximated regex
        pattern = r'\.controls\s*\{\s*display:\s*flex;\s*gap:\s*25px;\s*width:\s*300px;[\s\S]*?\}'
        if re.search(pattern, content):
             content = re.sub(pattern, """
    .controls {
      display: flex;
      flex-direction: row;
      gap: 30px;
      align-items: flex-start;
    }
""", content)
             modified = True
        
        # Also clean up .color-section if needed?
        # iphone4s had: width: 150px; /* ?? IMPORTANT */
        # iphone11 had: width: 150px; display: flex; flex-direction: column; gap: 10px;
        
        pattern_color = r'\.color-section\s*\{\s*width:\s*150px;\s*/\* \?\? IMPORTANT \*/\s*\}'
        if re.search(pattern_color, content):
            content = re.sub(pattern_color, """
    .color-section {
      width: 150px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
""", content)
            modified = True
            
        # Also add .sticker-section css if missing
        if '.sticker-section {' not in content:
             # insert it somewhere? Maybe after controls
             content = content.replace('.controls {', '.sticker-section { width: 150px; }\n    .controls {')
             modified = True

    if modified:
        print(f"Updating {file_path}")
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)

print("Mass update complete.")
