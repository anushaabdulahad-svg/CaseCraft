import glob
import re

files = glob.glob(r"c:/Users/Hamza-PC/Anusha Abdul Ahad_canva lab task/Desktop/ihatemylife/cococraft/iphone*.html")

# New addToCart function (template)
# We need to preserve the specific logic per file?
# Actually, the addToCart logic is nearly identical across files, except for "productName" and maybe basePrice (usually 20).
# In iphone11.html: productName: "iphone11 Custom Case"
# In iphone4S.html: productName: "iphone4S Custom Case" (or "Back Customizer" replace logic)

# To be safe, I should parse the *existing* addToCart body, extract the pricing/cartItem part, 
# and wrap it with the login check.

for file_path in files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Regex to find addToCart function body
    match = re.search(r'function addToCart\(\)\s*\{([\s\S]*?)\n\}\s*(?=window\.openCart|function|$)', content)
    if match:
        original_body = match.group(1)
        
        # Check if already has the specific login check at top
        if 'alert("login first")' in original_body:
            continue

        # Extract the core logic (everything after potential previous login checks or just the whole thing)
        # My previous script replaced logic with just `alert("Item added...")` in some places, 
        # OR left the cart addition logic and replaced the redirect.
        # Let's assume the body currently looks like:
        #   calculate price...
        #   cart item ...
        #   push to localstorage...
        #   alert("Item added...");
        
        # We want to PREPEND the login check.
        
        login_check = """
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true";
    if (!isLoggedIn) {
        alert("login first");
        window.location.href = "login.html";
        return;
    }
"""
        # If the body already does cart.push, we put login check BEFORE it.
        # Ideally at the very start of function.
        
        new_body = login_check + original_body
        
        # Replace in content
        new_content = content.replace(original_body, new_body)
        
        # Also, check iphone4S structure "fix". 
        # User said "make structure same as other".
        # If I see <div class="controls"> ... </div> <div class="customization-container">
        # Ensure they are siblings inside .container.
        # I'll rely on my previous mass_fix.py which seemingly did this.
        # But I'll do a string replacement to be sure about one specific thing:
        # Some files might have `class="sticker-section"` content issues.
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Updated {file_path}")

print("Done.")
