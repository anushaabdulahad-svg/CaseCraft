# PowerShell script to fix sticker resize selection issue in all iPhone HTML files
$directory = "c:\Users\Hamza-PC\Anusha Abdul Ahad_canva lab task\Desktop\COCO\PhoneCaseWebsite"
$files = Get-ChildItem -Path $directory -Filter "iphone*.html"

foreach ($file in $files) {
    $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
    
    # Skip if already fixed (check for user-select: none in sticker-wrapper img)
    if ($content -match "\.sticker-wrapper img\s*\{[^}]*user-select:\s*none") {
        Write-Host "Already fixed: $($file.Name)" -ForegroundColor Green
        continue
    }
    
    # Fix 1: Add user-select: none to .sticker-wrapper img
    # Pattern 1: Multi-line format with proper indentation
    $pattern1 = '(\.sticker-wrapper img \{\r?\n\s*width: 60px;\r?\n\s*display: block;\r?\n\s*\})'
    $replacement1 = @"
.sticker-wrapper img {
      width: 60px;
      display: block;
      user-select: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      pointer-events: none;
    }
"@
    
    # Pattern 2: Single-line format
    $pattern2 = '\.sticker-wrapper img \{ width: 60px; display: block; \}'
    $replacement2 = @"
.sticker-wrapper img {
      width: 60px;
      display: block;
      user-select: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      pointer-events: none;
    }
"@
    
    $modified = $false
    
    # Try pattern 1
    if ($content -match $pattern1) {
        $content = $content -replace $pattern1, $replacement1
        $modified = $true
    }
    # Try pattern 2
    elseif ($content -match $pattern2) {
        $content = $content -replace $pattern2, $replacement2
        $modified = $true
    }
    
    # Fix 2: Add e.preventDefault() to resize function
    # Add preventDefault to handle.onmousedown
    $pattern3 = '(handle\.onmousedown = e => \{\r?\n\s*e\.stopPropagation\(\);)\r?\n(\s*resizing = true;)'
    $replacement3 = "`$1`r`n        e.preventDefault();`r`n`$2"
    
    if ($content -match $pattern3) {
        $content = $content -replace $pattern3, $replacement3
        $modified = $true
    }
    
    # Add preventDefault to document.onmousemove in resize function
    $pattern4 = '(document\.onmousemove = e => \{\r?\n\s*if \(!resizing\) return;)\r?\n(\s*img\.style\.width)'
    $replacement4 = "`$1`r`n        e.preventDefault();`r`n`$2"
    
    if ($content -match $pattern4) {
        $content = $content -replace $pattern4, $replacement4
        $modified = $true
    }
    
    if ($modified) {
        Set-Content -Path $file.FullName -Value $content -Encoding UTF8 -NoNewline
        Write-Host "Fixed: $($file.Name)" -ForegroundColor Yellow
    }
    else {
        Write-Host "No changes needed: $($file.Name)" -ForegroundColor Cyan
    }
}

Write-Host "`nAll files processed!" -ForegroundColor Green
