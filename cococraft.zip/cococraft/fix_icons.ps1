$files = Get-ChildItem "iphone*.html"

foreach ($file in $files) {
    $content = Get-Content $file.FullName -Raw -Encoding UTF8
    
    # Define emojis using Unicode code points to avoid script encoding issues
    # 🗑 = \uD83D\uDDD1 -> In PowerShell string: "$([char]0xD83D)$([char]0xDDD1)"
    $trashIcon = "$([char]0xD83D)$([char]0xDDD1)"
    
    # 📄 = \uD83D\uDCC4 -> "$([char]0xD83D)$([char]0xDCC4)"
    $pageIcon = "$([char]0xD83D)$([char]0xDCC4)"
    
    # 🔍 = \uD83D\uDD0D -> "$([char]0xD83D)$([char]0xDD0D)"
    $searchIcon = "$([char]0xD83D)$([char]0xDD0D)"

    if ($content.Contains('del.innerHTML = "??";')) {
        Write-Host "Fixing Delete icon in $($file.Name)"
        $content = $content.Replace('del.innerHTML = "??";', "del.innerHTML = `"$trashIcon`";")
    }

    if ($content.Contains('copy.innerHTML = "??";')) {
         Write-Host "Fixing Copy icon in $($file.Name)"
        $content = $content.Replace('copy.innerHTML = "??";', "copy.innerHTML = `"$pageIcon`";")
    }

    if ($content.Contains('resize.innerHTML = "??";')) {
         Write-Host "Fixing Resize icon in $($file.Name)"
        $content = $content.Replace('resize.innerHTML = "??";', "resize.innerHTML = `"$searchIcon`";")
    }

    Set-Content -Path $file.FullName -Value $content -Encoding UTF8
}
Write-Host "Icons Fixed!"
